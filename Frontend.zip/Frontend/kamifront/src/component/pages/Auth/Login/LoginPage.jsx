import React from "react";
import { LoginSection } from "../../../section/Auth/Login/LoginSection";

export const LoginPage = () => {
  return (
    <div>
      <LoginSection />
    </div>
  );
};
