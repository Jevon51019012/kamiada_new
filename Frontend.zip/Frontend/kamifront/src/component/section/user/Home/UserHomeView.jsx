import React from "react";

export const UserHomeView = () => {
  return (
    <div className="bg-red-400">
      <h1 className="grid justify-items-center text-3xl font-bold underline">
        Hello world!
      </h1>
    </div>
  );
};
