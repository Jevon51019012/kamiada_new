import React from 'react'

export const PAgeNotFound = () => {
  return (
    <div>404PAgeNotFound</div>
  )
}
