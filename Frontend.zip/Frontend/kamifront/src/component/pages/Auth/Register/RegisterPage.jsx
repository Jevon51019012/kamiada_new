import React from "react";
import { RegisterSection } from "../../../section/Auth/Register/RegisterSection";

export const RegisterPage = () => {
  return (
    <div>
      <RegisterSection />
    </div>
  );
};
